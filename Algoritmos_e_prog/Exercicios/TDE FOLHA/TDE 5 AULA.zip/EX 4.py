num = int(input("digite um número: "))

par_impar = num%2

if par_impar == 0:
    print("Este número é par")
else:
    print("Este número é ímpar")
if num >= 0:
    print("Este é um número positivo")
else:
    print("Este é um número negativo")
    