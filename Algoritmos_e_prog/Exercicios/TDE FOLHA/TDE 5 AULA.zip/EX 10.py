conta_banc = float(input("Digite o valor disponível na sua conta bancária: "))

if conta_banc >= 0:
    print("CONTA NORMAL")
else:
    print("CONTA ESTOURADA")
