num1 = int(input("primeiro número: "))
num2 = int(input("segundo núemro: "))

dif1 = num1-num2
dif2 = num2-num1

if num1 > num2:
    print("A diferença do num1 pelo num2 é: ",dif1)
else:
    print("A diferença do num2 pelo num1 é: ",dif2)
    