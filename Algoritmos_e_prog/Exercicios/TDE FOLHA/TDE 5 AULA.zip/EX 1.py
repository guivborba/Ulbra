numA = int(input("digite o primeiro número: "))
numB = int (input("digite o segundo número: "))

somaA = numA+100
somaB = numB+100

if numA > numB:
    print("O primeiro número + 100 é igual: ",somaA)
else:
    print("O segundo número + 100 é igual: ",somaB)
