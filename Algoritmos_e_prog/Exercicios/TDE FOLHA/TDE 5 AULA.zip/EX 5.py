num1 = int(input("Primeiro núm: "))
num2 = int(input("Segundo núm: "))

if num1 == num2:
    print("São números iguais")
elif num1 > num2:
    print("O núemro 1 é maior que o número 2")
else:
    print("O número 2 é maior que o número 1")
    