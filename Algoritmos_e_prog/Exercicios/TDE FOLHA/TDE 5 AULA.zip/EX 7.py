num1 = int(input("Primeiro núm: "))
num2 = int(input("Segundo núm: "))

if num1 > num2:
    print(num1+num2)
else:
    print(num1-num2)